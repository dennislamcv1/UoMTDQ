#!/usr/bin/env python
# coding: utf-8

"""
This code was developed to help researchers to impute missing values (continous) in data.
------
Author: Jinseok Kim (Ph.D.),
        Research Assistant Professor at Survey Research Center, Institute for Social Research,
        and School of Information, University of Michigan - Ann Arbor
Date: 12/02/2021
"""


''' Packages required to be installed '''
"""
numpy, pandas, matplotlib, and sklearn
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.neighbors import KNeighborsRegressor
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_squared_error as mse

''' inlucded in python standar library '''
import time as tm
from datetime import timedelta


def encode_column(input_df, column_name_list):
    
    """
    This encodes categorical vlaues in a column into an array of columns (a.k.a. one-hot-encoding).
    ------
    :param input_df: a pandas dataframe object
    :param column_name_list: a list ([]) of column names to encode
    ------
    :return: a pandas dataframe in which a column is one-hot-encoded
             into N (no. of categories in the column to encode) columns
    """
    
    ''' initialized an encoder '''
    encoder = OneHotEncoder()
        # For details, https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.OneHotEncoder.html
		# Note: for linear regression, use OneHotEncoder(drop='first')
    
    ''' transform column(s) into an array of encoded values ''' 
    encoded_column = encoder.fit_transform(input_df[column_name_list]).toarray()
        # if OneHotEncoder(sparse=False), toarray() is not required
    
    ''' get names for encoded array '''
    encoded_column_names = encoder.get_feature_names_out()
        # feature names are alphabetically ordered by scikit learn
        # added for future use (e.g., printing encoded columns)
    
    ''' create a pandas dataframe using the encoded array and feature names '''
    encoded_df = pd.DataFrame(encoded_column, columns = encoded_column_names )
    
    return encoded_df


def add_encoded_column(input_df, column_name_list):
    
    """
    This appends encoded columns to input datdaframe and delete before-encoded columns.
    ------
    :param input_df: a pandas dataframe object
    :param column_name_list: a list ([])of column names to encode
    ------
    :return: a pandas dataframe in which a list of columns is one-hot-encoded
             into N (no. of categories in the columns to encode) columns and
             before-encoded columns are deleted
    """
    
    ''' create a dataframe of encoded columns '''
    encoded_df = encode_column(input_df, column_name_list)
    
    ''' drop columns which encoded columns are created from '''
    ohe_df = input_df.drop(columns = column_name_list)
    
    ''' add encoded dataframe to input dataframe '''
    ohe_df = ohe_df.join(encoded_df)
    
    return ohe_df 
    

def filter_nan(input_df, column_name):
    
    """
    This split an input data into subsets of rows where a value of a specified column
    is a numpy nan ('not a number') and those with non nan values.
    ------
    :param input_df: a pandas dataframe object
    :param column_name: a column name to be imputed
    ------
    :return: two pandas dataframe objects (df_notna, df_isna)
    """
    
    ''' create train and test sets '''
    df_isnan  = input_df.loc[input_df[column_name].isna()]  # or '.isnull()'
        # 'df_isnan' consists of rows with np.nan values in the to-be-imputed column
    
    df_notnan = input_df.drop(df_isnan.index)
        # 'df_notnan' consists of remaining rows
    
    return df_notnan, df_isnan


def split_train_test(input_df, column_name, test_set_ratio=None):
    
    """
    This split input data into train and test subsets for machine learning.
    ------
    :param input_df: a pandas dataframe object
    :param column_name: a column name to be imputed
    :param test_set_ratio: a float number between zero and one
    ------
    :return: four pandas dataframe objects (train_X, train_y, test_X, test_y)
             If 'test_set_ratio' is not None, rows with np.nan values are excluded
             Otherwise, a test set is made of rows with np.nan values and 
             remaining rows make up a train set 
    """
    
    if test_set_ratio is not None:
        
        ''' split 'input_df' into 'df_isnan' and 'df_notnan' subsets '''
        df_notnan, df_isnan = filter_nan(input_df, column_name)
            # only rows in 'df_notnan' are used for sampling as they have truth values
            
        ''' split data into train and test subsets using 'test_set_ratio' '''
        test_set = df_notnan.sample(frac=test_set_ratio, random_state=42)
            # 'random_state=42' generates the same results for reproducibility
        train_set  = df_notnan.drop(test_set.index)
        
    else:
        ''' create train and test sets from the entire 'input_df' '''
        train_set, test_set = filter_nan(input_df, column_name)
    
    ''' create a feature set and a label set from each of train and data sets '''
    train_y   = np.array(train_set[column_name])
    train_X   = train_set.drop(columns = column_name)
    test_y    = np.array(test_set[column_name])
    test_X    = test_set.drop(columns = column_name)
    
    return train_X, train_y, test_X, test_y


def run_imputer(train_X, train_y, test_X, imputer_name):
    
    """
    This applies imputer (or learner) to train and test subsets and produces an array of imputed values.
    ------
    :param train_X, train_y, test_X: pandas dataframe objects
    :param imputer_name: a text string of an imputer
    ------
    :return: a numpy array of imputed values
    """    
    
    ''' create a set of imputer names to check '''
    simple_imputer_names = {'mean', 'median', 'most_frequent'}
    
    if imputer_name in simple_imputer_names:
        
        ''' choose a simple imputer '''
        imputer_simple = SimpleImputer(strategy = imputer_name)
            # Can only use these strategies: ['mean', 'median', 'most_frequent', 'constant']
            # For details, https://scikit-learn.org/stable/modules/generated/sklearn.impute.SimpleImputer.html
        
        ''' get a value to be used for imputation from 'train_y' '''
        imputer_simple.fit(np.expand_dims(train_y, axis = 1))
        
        ''' create an empty array and populate it with np.nan values '''
        y = np.empty(len(test_X))
        y[:] = np.nan
        
        ''' insert imputation values '''
        imputed_values = imputer_simple.transform(np.expand_dims(y, axis = 1))

    else:
        
        ''' choose a learner (= imputer) from machine learning algorithms '''
        if   imputer_name == 'LNR':
            learner = LinearRegression()
            # For details, https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
        elif imputer_name == 'KNN':
            learner = KNeighborsRegressor()
            # For details, https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsRegressor.html
        elif imputer_name == 'DTR':
            learner = DecisionTreeRegressor()
            # For detail, https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeRegressor.html
        elif imputer_name == 'GBR':
            learner = GradientBoostingRegressor()
            # For details, https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.GradientBoostingRegressor.html
        else:
            print("Please, check names for imputers")

        ''' fit training data to a learner's model '''
        learner.fit(train_X, train_y)
        
        ''' predict values in test data '''
        imputed_values = learner.predict(test_X)

    return imputed_values


def merge_imputed_data(input_df, column_name, test_X, imputed_values):
    
    """
    This merge input data with imputed columns.
    ------
    :param input_df: a pandas dataframe object
    :param column_name: a column name to be imputed 
    :param test_X: a pandas dataframe that contain feature information for test set
    :param imputed_values: a numpy array of imputed values
    ------
    :return: a dataframe where a column is imputed for missign values
    """
    
    ''' create a copy of 'test_X '''
    test_imputed = test_X.copy()    
    
    ''' convert imputed_values into a pandas Series dataframe and format float numbers '''
    imputed_values_series = pd.Series(imputed_values.flatten()).apply(lambda x: f'{x:.2f}')
    
    ''' add a column 'imputed_value' filled by imputed values '''
    test_imputed['imputed_value'] = imputed_values_series.values
    
    ''' add a column 'imputation_flag' to indicate if a value is imputed '''
    flag_column = np.empty(len(test_imputed))
    flag_column[:] = 1
    test_imputed['imputation_flag'] = flag_column
    
    ''' filter 'imputed_value' and 'imputation_flag' columns '''
    test_filtered = test_imputed.loc[:, 'imputed_value':'imputation_flag']
    
    ''' merge the filtered test data with the original dataframe '''
    merged_data = pd.merge(input_df, test_filtered, left_index = True, right_index = True, how = 'left')
    
    ''' replace values in column name with those in the 'imputed_value' column '''
    merged_data[column_name] = np.where(merged_data['imputed_value'].notnull(),
                                        merged_data['imputed_value'],
                                        merged_data[column_name])

    ''' drop the 'imputed_value' column '''
    merged_data = merged_data.drop(columns = 'imputed_value')

    ''' replace np.nan values in 'imputation_flag' with zeros '''
    merged_data['imputation_flag'] = np.where(merged_data['imputation_flag'].isnull(),
                                              0,
                                              merged_data['imputation_flag'])

    return merged_data


def append_columns(input_df, column_name, imputer_name, imputed_values):
    
    """
    This appends columns imputed by imputers to an input dataframe.
    ------
    :param input_df: a pandas dataframe object
    :param column_name: a column name to be imputed 
    :param imputer_name: a name of an imputer
    :param imputed_values: a numpy array of imputed values
    ------
    :return: a dataframe where each column is filled with values imputed by an imputer 
    """
    
    ''' convert imputed_values into a pandas Series dataframe and format float numbers '''
    imputed_values_series = pd.Series(imputed_values.flatten()).apply(lambda x: f'{x:.2f}')
    
    ''' add a column of values impuated by an imputer '''
    column_name_combined = str(column_name) + "_" + str(imputer_name)
    input_df[column_name_combined] = imputed_values_series.values
    
    return input_df
    

def append_imputed_data(input_df, df_test_X):
    
    """
    This adds a dataframe of imputed columns by imputers to the before-imputation input data.
    ------
    :param input_df: a pandas dataframe object
    :param df_test_X: a pandas dataframe that contain columns of imputed values
    ------
    :return: a dataframe where a list of columns with imputed values are appended to the original dataframe
    """
    
    ''' merge the filtered test data with the original dataframe '''
    merged_data = pd.merge(input_df, df_test_X, left_index = True, right_on = 'index', how = 'left')
    
    ''' remove the column of 'index' in df_test_X '''
    merged_data = merged_data.drop(columns = 'index')
    
    return merged_data
    

def print_output(imputed_df, imputer_name, test_set_ratio=None):
    
    """
    This writes imputed data on a csv file.
    ------
    :param imputed_df: a pandas dataframe object
    :param imputer_name: a text string of an imputer
    :param test_set_ratio: a float number between zero and one
    ------
    :return: an output file stored in a current working directory and a print message
    """
  
    ''' decide an output file name '''
    if test_set_ratio is None:
        ''' missing values in the original file are imputed '''
        file_name = "output_imputed_data " + str(imputer_name) + ".csv"
    
    else:
        ''' sampled values in the original file are imputed for test '''
        file_name = "output_imputed_data test.csv"
    
    ''' write an output dataframe to aa output file ''' 
    imputed_df.to_csv(file_name, sep = ",", encoding = "utf-8", index = False)
    
    ''' print a message '''
    print("\nAn output file '" + str(file_name) + "' was created in the current working directory.")


def evaluate_performance(test_y, imputed_values):
    
    """
    This measures the performance of an imputer on truth information in a test subset.
    ------
    :param test_y: a numpy array that contains labels for a test set column to be imputed
    :param imputed values: a numpy array of imputed values
    ------
    :return: a performance score of an imputation task
    """
    
    ''' calculate RMSE '''
    
    rmse = mse(test_y, imputed_values, squared=False)
        # metric: Root Mean Squared Error (RMSE) regression loss
        # For details, https://scikit-learn.org/stable/modules/generated/sklearn.metrics.mean_squared_error.html

    return rmse


def show_figure(imputer_name_list, imputer_score_list):

    """
    This displays the performances of imputers on a 2-d figure.
    ------
    :param imputer_name_list: a list of imputer names
    :param imputer_score_list: a list of imputer performance scores
    ------
    :return: a figure that visualizes imputer peformances in bar graphs
    """
    
    ''' setup figure size, colors, and legends '''
    fig = plt.figure(figsize = [9, 6], dpi = 120)
    fig.patch.set_alpha(0)
    ax = fig.add_subplot(111)
    ax.set_title('Comparison of Imputer Performance', fontsize = 16)
    ax.set_xlabel('Imputer', fontsize = 14)
    ax.set_ylabel('RMSE', fontsize = 14)
    ax.bar(imputer_name_list, imputer_score_list, width = 0.5)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.xaxis.set_tick_params(length = 0)
    ax.yaxis.set_tick_params(length = 0)
    ax.patch.set_alpha(0)
    
    ''' decide the size and position of value strings '''
    for idx, val in enumerate(imputer_score_list):
        ax.text(idx - 0.15, val + 1, str(f'{val:.2f}'))
    
    plt.show()


def main(input_df,
         columns_to_encode,
         column_to_impute,
         imputer_name_list,
         test_set_ratio=None,
         print_or_not=None,
         evaluate_or_not=None): 

    ''' define a list to record evaluation scores '''
    if evaluate_or_not is not None:
        imputer_score_list = []
    
    ''' conduct one-hot-encoding, if chosen '''
    if columns_to_encode != []:
        ohe_df = add_encoded_column(input_df, columns_to_encode)
    else:
        ohe_df = input_df.copy()

    ''' create train and test files for imputation '''    
    train_X, train_y, test_X, test_y = split_train_test(ohe_df, column_to_impute, test_set_ratio)    

    
    if test_set_ratio is not None:
        
        ''' Create a dataframe with a column of test_X indices '''
        test_X_indices = test_X.index.values
        df_test_X = pd.DataFrame()
        df_test_X['index'] = test_X_indices
    
    ''' impute missing values '''
    for imputer_name in imputer_name_list:
        
        ''' run an imputation method '''
        imputed_values = run_imputer(train_X, train_y, test_X, imputer_name)
        
        if test_set_ratio is not None:
            
            ''' append a column of impuated values by an imputer to df_test_X '''
            append_columns(df_test_X, column_to_impute, imputer_name, imputed_values)
        
        else:
        
            ''' merge imputation results with input data '''
            imputed_df = merge_imputed_data(input_df, column_to_impute, test_X, imputed_values)
            
            if print_or_not is not None:
                ''' print imputation results in a file '''
                print_output(imputed_df, imputer_name, test_set_ratio)

        
        if evaluate_or_not is not None:
            ''' calculate a performance score '''
            eval_score = evaluate_performance(test_y, imputed_values)
            imputer_score_list.append(eval_score)

    
    if test_set_ratio is not None:
        
        ''' merge imputation results with input data '''
        appended_df = append_imputed_data(input_df, df_test_X)
        
        if print_or_not is not None:
            ''' print imputation results in a file '''
            print_output(appended_df, None, test_set_ratio)
    

    if evaluate_or_not is not None:

        ''' print a performance report on screen '''
        print("\n### Imputer Performance Score ###\n'Imputer': 'Score'")
        for index, value in enumerate(imputer_name_list):
            print(str(value) + ": " + str(f'{imputer_score_list[index]:.2f}'))

        ''' show a figure that reports performance results '''
        show_figure(imputer_name_list, imputer_score_list)


if __name__== "__main__":

    """ 
    This asks users to input information about data and parameters and implements main function.
    """   
    
    ''' STEP 1: Loading and Describing Data '''
    
    message = """
    STEP1: Enter a csv file name you want to load (e.g., flights_nan.csv)
    """
    print(message)
    
    input_file_name = input()

    loaded_data = pd.read_csv(input_file_name, sep = ',', encoding = "utf-8")
    
    message = """
    Below is the basic information about the loaded data.
    """
    print(message)

    loaded_data.info()

    
    ''' Step 2: Choosing a column to impute '''
    
    message = """
    Step 2: Choose a column to impute (e.g., passengers).
    Type ONE column name as shown in the information provided above
    """
    print(message)

    column_to_impute = input()

    
    ''' Step 3: Filtering columns to be used for ML imputation '''
    
    message = """
    Step 3: Choose columns to be used for imputation by machine learning.
    You need to choose at least one column other than the column to impute.
    If you choose two or more columns, type column names separted by spaces (e.g., year month)
    """
    print(message)
    
    columns_to_use = input().split()
    columns_to_use.append(column_to_impute) # this appends column_to_impute at the end of dataframe
    input_df = loaded_data.filter(items = columns_to_use)

    message = """
    Below is the basic information about the filtered data for imputation.
    """
    print(message)

    input_df.info()

    ''' Step 4: Picking up columns to be one-hot-encoded '''
    
    message = """
    Step 4: Choose a column to be encoded by one-hot-encoding, if needed (e.g., month)
    If you need to encode two or more columns, type column names separted by spaces (e.g., month year)
    """
    print(message)

    columns_to_encode = input().split()

    
    ''' Step 5: Setting a test set size '''
    
    message = """
    Step 5: Do you want to run an imputation with an evaluation test?
    If so, please set a ratio (between zero and one; e.g., 0.2) for a test set size.
    For example, 0.2 means that a test set consists of 20% of the rows in the loaded data.
    If you don't want to run an evaluation test, just press the Enter key.
    """
    print(message)

    input_ratio = input()

    if input_ratio != '':
        test_set_ratio = float(input_ratio)
    else:
        test_set_ratio = None

    ''' Step 6: Choosing imputers '''
    
    message = """
    Step 6: Select names of imputer you want to run.
    Below are the names of available imputers.

    Simple imputers: mean, median, most_frequent

    ML imputers: LNR (--> Linear Regression),
                 KNN (--> K-Neighbors Regressor),
                 GBR (--> Gradient Boosting Regressor),
                 DTR (--> Decision Tree Regressor)

    You should type a name exactly as shown in the list.
    If you choose two or more imputers, type their names separted by spaces (e.g., mean KNN)
    """
    print(message)

    imputer_name_list = input().split()

    
    ''' Step 7: Printing of output files '''
    
    message = """
    Step 7: Do you want to print imputation results in an output file?
    If so, please type 1.
    Otherwise, press the Enter key.
    """
    print(message)

    print_or_not = input()
    
    if print_or_not == '':
        print_or_not = None

    ''' Step 8: Report of evaluation results '''
    
    if test_set_ratio is not None:
    
        message = """
        Step 8: Do you want a report on evaluation results?
        If so, please type 1.
        Otherwise, press the Enter key.
        To choose 1, you should have set the 'test set ratio' above.
        """
        print(message)

        evaluate_or_not = input()

        if evaluate_or_not == '':
            evaluate_or_not = None

    else:
        
        message = """
        Step 8: You chose not to provide a test set size.
        So, evaluation results are unavailable.
        """
        print(message)
        
        evaluate_or_not = None;
    
    print("\nImputation in progress ...\n")
    
    ''' measure start time '''
    start_time = tm.time()
    
    ''' excute imputation '''
    main(input_df,
         columns_to_encode,
         column_to_impute,
         imputer_name_list,
         test_set_ratio = test_set_ratio,
         print_or_not = print_or_not,
         evaluate_or_not = evaluate_or_not)   
    
    print("\nImputation completed!!!\n")
    
    ''' measure finish time and print runtime '''
    elapsed_time_secs = tm.time() - start_time

    msg = "\nRuntime: %s secs" % timedelta(seconds=round(elapsed_time_secs))

    print(msg)

''' The End of Line '''
